package com.example.agendador;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

public class ClienteHome extends AppCompatActivity {

    private TextView nomeCliente;
    private ClientesDAO conexaoBanco;
    private BottomNavigationView navView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cliente_home);

        navView = findViewById(R.id.nav_view);
//        nomeCliente = findViewById(R.id.nomeUser);
        conexaoBanco = new ClientesDAO(getBaseContext());
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);
    }

    public void logoff(View v){

        // destruir sessao
        SharedPreferences preferencias = getSharedPreferences(
                "user_preferences", // 1 - chave das preferencias buscadas
                MODE_PRIVATE);      // 2 - modo de acesso
        SharedPreferences.Editor editor = preferencias.edit();

        editor.remove("login").apply();

        finish();


    }

    public void alterarDados(View v){

        Intent alteraDados = new Intent(getBaseContext(), alteraDados.class);
        startActivity(alteraDados);

    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences preferencias = getSharedPreferences(

                "user_preferences",
                MODE_PRIVATE);

        String idUser = preferencias.getString( // Pego ID do usuario na sessao
                "login",
                "idUser");

        Integer id = Integer.parseInt(idUser);
        String nome = conexaoBanco.retornaNome(id);
        //nomeCliente.setText(nome);

    }

}
