package com.example.agendador;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class alteraDados extends AppCompatActivity {

    private EditText editTextNome, editTextCPF, editTextSenha, editTextEmail;
    private Cliente cliente = null;

    // objeto para manipular dados
    private ClientesDAO conexaoBanco;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.altera_dados);

        conexaoBanco = new ClientesDAO(getBaseContext());

        editTextNome = findViewById(R.id.nomeAlt);
        editTextEmail = findViewById(R.id.emailAlt);
        editTextCPF = findViewById(R.id.cpfAlt);
        editTextSenha = findViewById(R.id.senha2Alt);

        SharedPreferences preferencias = getSharedPreferences("user_preferences", MODE_PRIVATE);
        String idUser = preferencias.getString( "login", "idUser");
        Integer id = Integer.parseInt(idUser);

        Cliente clientealterado = cliente;
        cliente = conexaoBanco.retornaCliente(id);

        editTextNome.setText(cliente.getNome());
        editTextEmail.setText(cliente.getEmail());
        editTextCPF.setText(cliente.getCPF());
        editTextSenha.setText(cliente.getSenha());

    }

    public void alterarDados(View v){

        // valida dados
        if(!validaForm()){
            return; // para a execução da função
        }
        // capta os dados da tela
        String nome = editTextNome.getText().toString();
        String CPF = editTextCPF.getText().toString();
        String email = editTextEmail.getText().toString();
        String senha = editTextSenha.getText().toString();


        // altera dados na tabela
        cliente.setNome(nome);
        cliente.setEmail(email);
        cliente.setCPF(CPF);
        cliente.setSenha(senha);

        // executa operação do banco
        int linhas =conexaoBanco.atualizar(cliente);

        // mensagem para o usuário informando sucesso
        if(linhas > 0){

            Toast.makeText(getApplicationContext(),
                    "Dados alterados com sucesso",
                    Toast.LENGTH_SHORT).show();

            finish();

        } else {
            Toast.makeText(getApplicationContext(),
                    "Erro ao alterar dados",
                    Toast.LENGTH_SHORT).show();
            cliente = null; // ajuda na hora de debug
        }

        //}
    }

    public boolean validaForm() {
        String nome = editTextNome.getText().toString();
        String cpf = editTextCPF.getText().toString();
        String senha = editTextSenha.getText().toString();
        String email = editTextEmail.getText().toString();

        if (nome.isEmpty()) {
            editTextNome.setError("O campo nome é obrigatório!");
            editTextNome.requestFocus();
            return false;
        }

        if (cpf.isEmpty()) {
            editTextCPF.setError("O campo CPF é obrigatório!");
            editTextCPF.requestFocus();
            return false;
        }

        if (senha.isEmpty()) {
            editTextSenha.setError("O campo senha é obrigatório!");
            editTextSenha.requestFocus();
            return false;
        }

        if (email.isEmpty()) {
            editTextEmail.setError("O campo de email é obrigatório!");
            editTextEmail.requestFocus();
            return false;
        }

        return true;
    }

    public void voltarHome(View view) {
        finish();
    }
}
